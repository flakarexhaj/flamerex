import { useEffect, useMemo, useState } from "react";
import StatCard from "./components/StatCard";
import Charts from "./components/Charts";
import EventTable from "./components/EventTable";
import EventDrawer from "./components/EventDrawer";
import ThreatMap from "./components/ThreatMap";
import Landing from "./components/Landing";
import AboutSection from "./components/AboutSection";
import ContactSection from "./components/ContactSection";
import { SeverityBadge, StatusText } from "./components/Badge";
import { SECTIONS, SECTION_INFO, readHash, type Section } from "./sections";
import { useStore } from "./store";

export default function App() {
  const [section, setSection] = useState<Section>(readHash);

  const events = useStore((s) => s.events);
  const live = useStore((s) => s.live);
  const dark = useStore((s) => s.dark);
  const addEvent = useStore((s) => s.addEvent);
  const select = useStore((s) => s.select);
  const toggleLive = useStore((s) => s.toggleLive);
  const toggleDark = useStore((s) => s.toggleDark);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  useEffect(() => {
    if (!live) return;
    const id = window.setInterval(addEvent, 4000);
    return () => window.clearInterval(id);
  }, [live, addEvent]);

  // Only one section is shown at a time. The URL hash keeps the back button and shared links working.
  useEffect(() => {
    const onHash = () => {
      setSection(readHash());
      select(null);
      window.scrollTo(0, 0);
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, [select]);

  const go = (s: Section) => { window.location.hash = s; };

  const recent = useMemo(() => [...events].sort((a, b) => b.time - a.time).slice(0, 8), [events]);

  if (section === "home") return <Landing onNavigate={go} />;

  const dayAgo = Date.now() - 86400_000;
  const last24 = events.filter((e) => e.time > dayAgo).length;
  const critical = events.filter((e) => e.severity === "critical" && e.status !== "resolved").length;
  const open = events.filter((e) => e.status === "open").length;
  const resolvedPct = events.length
    ? Math.round((events.filter((e) => e.status === "resolved").length / events.length) * 100)
    : 0;

  const info = SECTION_INFO[section];

  return (
    <div className="min-h-screen text-slate-900 dark:text-slate-100">
      <div className="flex min-h-screen">
        {/* SIDEBAR */}
        <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-amber-700/20 bg-white/80 p-5 backdrop-blur-xl dark:border-amber-400/15 dark:bg-[#0d0d0b]/90 md:flex">
          <button onClick={() => go("home")} className="mb-10 flex items-center gap-3 rounded-xl p-2 text-left" aria-label="FLAMERIX home">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-amber-500/50 bg-gradient-to-br from-amber-100 via-amber-300 to-amber-600 text-xl font-black text-[#211807] shadow-lg shadow-amber-500/10 dark:from-[#f5df9b] dark:via-[#d4af57] dark:to-[#76501b]">F</span>
            <span>
              <span className="block text-lg font-black tracking-[0.12em] text-amber-800 dark:text-[#e8c66a]">FLAMERIX</span>
              <span className="block text-[9px] tracking-[0.22em] text-slate-500 dark:text-stone-400">SECURITY SYSTEMS</span>
            </span>
          </button>

          <p className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400 dark:text-stone-500">Workspace</p>
          <nav className="space-y-2" aria-label="Sections">
            {SECTIONS.map((id) => (
              <button
                key={id}
                onClick={() => go(id)}
                aria-current={id === section ? "page" : undefined}
                className={`flex w-full items-center gap-3 rounded-xl border px-3 py-3 text-left text-sm transition ${
                  id === section
                    ? "border-amber-500/30 bg-amber-100/70 font-semibold text-amber-900 dark:border-amber-400/30 dark:bg-amber-400/10 dark:text-[#f5df9b]"
                    : "border-transparent text-slate-600 hover:border-amber-500/20 hover:bg-amber-50 dark:text-stone-400 dark:hover:bg-amber-400/5"
                }`}
              >
                <span className="w-6 text-center text-lg text-amber-600 dark:text-[#d4af57]">{SECTION_INFO[id].symbol}</span>
                {SECTION_INFO[id].label}
              </button>
            ))}
          </nav>

          <div className="mt-auto rounded-2xl border border-amber-600/20 bg-gradient-to-br from-amber-50 to-white p-4 dark:from-[#241d10] dark:to-[#11100d]">
            <div className="mb-2 flex items-center gap-2">
              <span className={`h-2 w-2 rounded-full ${live ? "animate-pulse bg-emerald-500" : "bg-slate-400"}`} />
              <span className="text-xs font-semibold">{live ? "Monitoring active" : "Monitoring paused"}</span>
            </div>
            <p className="text-xs leading-5 text-slate-500 dark:text-stone-400">Flamerix threat monitoring demo environment.</p>
          </div>
        </aside>

        {/* MAIN */}
        <main className="min-w-0 flex-1">
          <div className="mx-auto max-w-[1600px] space-y-6 p-4 sm:p-6 lg:p-8">
            {/* Mobile section tabs */}
            <nav className="flex gap-2 overflow-x-auto md:hidden" aria-label="Sections">
              {SECTIONS.map((id) => (
                <button
                  key={id}
                  onClick={() => go(id)}
                  aria-current={id === section ? "page" : undefined}
                  className={`shrink-0 rounded-lg border px-3 py-1.5 text-xs ${
                    id === section ? "border-amber-500/40 bg-amber-100/70 font-semibold text-amber-900 dark:bg-amber-400/10 dark:text-[#f5df9b]" : "border-amber-700/20 text-slate-600 dark:text-stone-400"
                  }`}
                >
                  {SECTION_INFO[id].label}
                </button>
              ))}
            </nav>

            <header className="rounded-2xl border border-amber-700/20 bg-white/75 p-5 shadow-sm backdrop-blur-xl dark:border-amber-400/15 dark:bg-[#11110f]/85 sm:p-6">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">{info.title}</h1>
                  <p className="mt-2 text-sm text-slate-500 dark:text-stone-400">{info.description}</p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <button onClick={toggleLive} aria-pressed={live} className="flex items-center gap-2 rounded-xl border border-amber-700/20 bg-white px-4 py-2.5 text-sm font-medium hover:bg-amber-50 dark:border-amber-400/20 dark:bg-[#181712] dark:hover:bg-amber-400/10">
                    <span className={`h-2 w-2 rounded-full ${live ? "animate-pulse bg-emerald-500" : "bg-slate-400"}`} />
                    {live ? "Live monitoring" : "Paused"}
                  </button>
                  <button onClick={toggleDark} aria-label={dark ? "Switch to light mode" : "Switch to dark mode"} className="rounded-xl border border-amber-700/20 bg-white px-4 py-2.5 text-sm font-medium hover:bg-amber-50 dark:border-amber-400/20 dark:bg-[#181712] dark:hover:bg-amber-400/10">
                    {dark ? "☼ Light" : "◐ Dark"}
                  </button>
                </div>
              </div>
            </header>

            {section === "events" && <EventTable />}

            {section === "intelligence" && (
              <div className="space-y-5">
                <ThreatMap />
                <div className="overflow-hidden rounded-2xl border border-amber-700/20 bg-white/80 dark:border-amber-400/15 dark:bg-[#11110f]">
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-amber-700/15 p-5 dark:border-amber-400/10">
                    <div>
                      <h2 className="font-semibold">Live Threat Feed</h2>
                      <p className="mt-1 text-xs text-slate-500 dark:text-stone-400">Most recent events recorded by this dashboard.</p>
                    </div>
                    <span className="text-xs text-slate-500 dark:text-stone-400">{events.length} events</span>
                  </div>
                  <ul className="divide-y divide-amber-700/10 dark:divide-amber-400/10">
                    {recent.map((e) => (
                      <li key={e.id} className="grid grid-cols-1 gap-2 p-4 transition hover:bg-amber-50/70 dark:hover:bg-amber-400/5 sm:grid-cols-[1fr_1fr_auto] sm:items-center">
                        <div className="min-w-0">
                          <p className="truncate text-sm font-semibold">{e.type}</p>
                          <p className="mt-1 text-xs text-slate-500 dark:text-stone-400">{e.ip} · {e.country}</p>
                        </div>
                        <div className="flex flex-wrap items-center gap-3">
                          <SeverityBadge value={e.severity} />
                          <StatusText value={e.status} />
                        </div>
                        <time className="text-xs text-slate-400 sm:text-right">
                          {new Date(e.time).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                        </time>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {section === "analytics" && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
                  <StatCard label="Events, last 24h" value={last24} hint="All severities" />
                  <StatCard label="Unresolved critical" value={critical} hint="Needs immediate attention" tone="danger" />
                  <StatCard label="Open events" value={open} hint="Not yet triaged" />
                  <StatCard label="Resolved" value={`${resolvedPct}%`} hint="Share of all events" />
                </div>
                <Charts events={events} />
              </div>
            )}

            {section === "about" && <AboutSection />}
            {section === "contact" && <ContactSection />}

            <footer className="flex flex-wrap items-center justify-between gap-2 border-t border-amber-700/15 py-4 text-xs text-slate-500 dark:border-amber-400/10 dark:text-stone-500">
              <span>FLAMERIX SECURITY · Portfolio project</span>
              <span>{events.length} demo events loaded</span>
            </footer>
          </div>
        </main>
      </div>
      <EventDrawer />
    </div>
  );
}
