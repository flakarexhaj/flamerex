// Edit these values: they appear in the About and Contact sections.
export const PROFILE = {
  name: "Your Name",
  role: "Front-end developer with a focus on cybersecurity",
  email: "you@example.com",
  linkedin: "https://www.linkedin.com/in/your-handle",
  github: "https://github.com/your-handle",
};
