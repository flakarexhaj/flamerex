export const SECTIONS = ["home", "events", "intelligence", "analytics", "about", "contact"] as const;
export type Section = (typeof SECTIONS)[number];

interface Info { num: string; label: string; title: string; description: string; symbol: string; }

export const SECTION_INFO: Record<Section, Info> = {
  home: { num: "01", label: "Home", title: "Home", description: "", symbol: "◈" },
  events: { num: "02", label: "Security events", title: "Security Events", description: "Search, filter, sort and update individual events.", symbol: "⌁" },
  intelligence: { num: "03", label: "Threat intelligence", title: "Threat Intelligence", description: "Geographic threat activity and recent security events.", symbol: "◎" },
  analytics: { num: "04", label: "Analytics", title: "Security Analytics", description: "Key numbers, activity trends and attack distribution.", symbol: "▥" },
  about: { num: "05", label: "About", title: "About", description: "Who is behind FLAMERIX and what this project is for.", symbol: "◇" },
  contact: { num: "06", label: "Contact", title: "Contact", description: "Get in touch.", symbol: "✉" },
};

export const readHash = (): Section => {
  const h = window.location.hash.replace("#", "");
  return (SECTIONS as readonly string[]).includes(h) ? (h as Section) : "home";
};
