import { SECTION_INFO, type Section } from "../sections";

// Poster size in pixels. Hotspot coordinates below are measured on the poster itself.
const W = 1086;
const H = 1448;
const BAR = 64; // height of the bottom navigation bar

interface Hotspot { label: string; to: Section; x: number; y: number; w: number; h: number; }

const HOTSPOTS: Hotspot[] = [
  { label: "Projects: open security events", to: "events", x: 585, y: 47, w: 100, h: 38 },
  { label: "Cybersecurity: open threat intelligence", to: "intelligence", x: 699, y: 47, w: 148, h: 38 },
  { label: "About", to: "about", x: 861, y: 47, w: 70, h: 38 },
  { label: "Contact", to: "contact", x: 946, y: 47, w: 92, h: 38 },
  { label: "See more: open security events", to: "events", x: 868, y: 468, w: 135, h: 90 },
];

const INDEX: Section[] = ["events", "intelligence", "analytics", "about", "contact"];

export default function Landing({ onNavigate }: { onNavigate: (s: Section) => void }) {
  return (
    <div className="min-h-screen bg-black">
      <div
        className="relative mx-auto"
        style={{ width: `min(100%, calc((100svh - ${BAR}px) * ${W / H}))`, aspectRatio: `${W} / ${H}` }}
      >
        <img
          src="/poster.png"
          alt="FLAMERIX. Exploring the intersection of cybersecurity, technology and creativity. Analyze. Protect. Build a safer digital world."
          draggable={false}
          className="absolute inset-0 h-full w-full select-none"
        />
        {HOTSPOTS.map((s) => (
          <button
            key={s.label}
            onClick={() => onNavigate(s.to)}
            aria-label={s.label}
            title={s.label}
            className="absolute cursor-pointer rounded-sm transition-colors hover:bg-purple-500/15 focus-visible:bg-purple-500/20"
            style={{ left: `${(s.x / W) * 100}%`, top: `${(s.y / H) * 100}%`, width: `${(s.w / W) * 100}%`, height: `${(s.h / H) * 100}%` }}
          />
        ))}
      </div>

      <nav
        aria-label="Sections"
        className="mx-auto flex flex-wrap items-center justify-center gap-x-8 gap-y-2 border-t border-white/10 px-4 py-4 font-mono text-[11px] tracking-[0.2em] text-stone-500"
        style={{ minHeight: BAR }}
      >
        {INDEX.map((id) => (
          <button key={id} onClick={() => onNavigate(id)} className="uppercase transition-colors hover:text-white">
            <span className="mr-2 text-purple-400">{SECTION_INFO[id].num}</span>
            {SECTION_INFO[id].label}
          </button>
        ))}
      </nav>
    </div>
  );
}
