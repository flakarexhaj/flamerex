import { PROFILE } from "../profile";

const SKILLS: Record<string, string[]> = {
  "Front-end": ["React", "TypeScript", "Tailwind CSS", "Vite"],
  "Data and state": ["Recharts", "TanStack Table", "Zustand"],
  "Quality and delivery": ["Vitest", "Testing Library", "Git", "Vercel"],
};

const FOCUS = [
  "Interfaces that make security data easy to read",
  "Web security basics: XSS, CSRF, SQL injection, authentication",
  "Accessible, responsive and tested front-end code",
];

export default function AboutSection() {
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <section className="rounded-2xl border border-amber-700/20 bg-white/80 p-6 dark:border-amber-400/15 dark:bg-[#11110f] lg:col-span-2">
        <h2 className="text-lg font-bold">{PROFILE.name}</h2>
        <p className="mt-1 text-sm text-amber-800 dark:text-[#d4af57]">{PROFILE.role}</p>
        <p className="mt-4 max-w-prose text-sm leading-6 text-slate-600 dark:text-stone-300">
          FLAMERIX is where I explore the intersection of cybersecurity, technology and creativity. I build
          front-end projects that turn complex security data into something a person can understand at a glance.
        </p>
        <h3 className="mt-6 text-sm font-semibold">About this project</h3>
        <p className="mt-2 max-w-prose text-sm leading-6 text-slate-600 dark:text-stone-300">
          This site is a security operations dashboard running on simulated data. It shows live events, a threat
          map, analytics, and a searchable event log with incident status management. Everything runs in the
          browser, with no backend.
        </p>
        <h3 className="mt-6 text-sm font-semibold">Focus</h3>
        <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-slate-600 dark:text-stone-300">
          {FOCUS.map((f) => <li key={f}>{f}</li>)}
        </ul>
      </section>

      <section className="rounded-2xl border border-amber-700/20 bg-white/80 p-6 dark:border-amber-400/15 dark:bg-[#11110f]">
        <h2 className="text-lg font-bold">Technologies</h2>
        <div className="mt-4 space-y-5">
          {Object.entries(SKILLS).map(([group, items]) => (
            <div key={group}>
              <h3 className="text-xs font-semibold text-slate-500 dark:text-stone-400">{group}</h3>
              <ul className="mt-2 flex flex-wrap gap-2">
                {items.map((s) => (
                  <li key={s} className="rounded-md border border-amber-600/25 px-2.5 py-1 text-xs text-amber-900 dark:text-[#f5df9b]">{s}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
